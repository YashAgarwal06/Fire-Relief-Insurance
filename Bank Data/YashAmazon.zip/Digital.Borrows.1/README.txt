This is a guide on how to view your digital content loans and borrows data.

Some data fields will have the data value “Not Available”. This means that there was no data present for that field.



Digital.Borrows.1.csv
- This file contains the data of all the loans and borrows for digital content that the customer has done